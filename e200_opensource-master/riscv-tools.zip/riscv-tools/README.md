riscv-tools [![Build Status](https://travis-ci.org/riscv/riscv-tools.svg?branch=master)](https://travis-ci.org/riscv/riscv-tools)
===========================================================================

This repo is just the hacked version from the original riscv-tools (from https://github.com/riscv/riscv-tools)

Since the original riscv-tools from https://github.com/riscv/riscv-tools keep updating and may be unstable, the purpose of this repo is to use a reduced version of riscv-tools to make it enough to be used by SI-RISCV/e200_opensource project and keep it stable. 

