Hummingbird E200 Opensource Processor Core

install RTL file and make .mcs file
================


For hbirdkit:

make install CORE=e203 FPGA_NAME=hbirdkit 

make mcs     CORE=e203 FPGA_NAME=hbirdkit 

================

For nucleikit:

make install CORE=e203 FPGA_NAME=nucleikit 

make mcs     CORE=e203 FPGA_NAME=nucleikit 

================

For artydevkit:

make install CORE=e203 FPGA_NAME=artydevkit 

make mcs     CORE=e203 FPGA_NAME=artydevkit 

================
