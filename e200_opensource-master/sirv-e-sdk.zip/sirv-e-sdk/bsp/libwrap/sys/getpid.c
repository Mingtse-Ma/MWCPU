/* See LICENSE of license details. */

int __wrap_getpid(void)
{
  return 1;
}
